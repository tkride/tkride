---
name: Bug Report
about: Found bug in the library
---
### Issue summary

### Expected behavior

### Actual behavior

### Steps to reproduce

### Browser and OS

<!--
You can create demo by forking this codepen http://codepen.io/jcubic/pen/MbVMwO

Please don't close the issue, I'm marking it as resolved and closing when merge to master

-->
